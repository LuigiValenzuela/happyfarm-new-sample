public interface Bakable {

    public void bake();
}
