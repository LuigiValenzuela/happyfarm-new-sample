public class Cat extends Animal {


    public void SayName() {
        System.out.println("Pinkerton");
    }

    public void MakeSound() {
        System.out.println("meow");
    }

    public void Muve() {
        System.out.println("jump");
    }




}
