public abstract class Animal {


    public abstract void MakeSound();
    public abstract void SayName();
    public abstract void Muve();


}
