public interface Meowable {

    public void meow();


}
