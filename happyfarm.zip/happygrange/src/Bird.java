public class Bird extends Animal {


    public void SayName() {
        System.out.println("Cotorro");
    }

    public void MakeSound() {
        System.out.println("Sing");
    }

    public void Muve() {
        System.out.println("Fly");
    }

}

