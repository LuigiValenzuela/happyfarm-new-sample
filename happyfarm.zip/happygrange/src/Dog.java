public class Dog extends Animal{

    public void SayName() {
        System.out.println("Somer");
    }

    public void MakeSound() {
        System.out.println("wooof");
    }

    public void Muve() {
        System.out.println("Run");
    }


}
